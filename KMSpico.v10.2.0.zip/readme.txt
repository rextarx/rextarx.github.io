this is my portable version of heldigard's incredible KMSpico
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
http://forums.mydigitallife.info/threads/65739-KMSpico-Official-Thread/

all credits to heldigard!


1. doubleclick KMSpico.exe
2. done!


doubleclick "Check_Activation.cmd" to check your activation status
doubleclick "Check_Logfile.cmd" to see the KMSpico logfile


my portable version is not installing anything permanent and works full automatic
whenever you want the program to be run, run it MANUALLY
no harm if you miss the 180 days, just run KMSpico then


you can use the following switches for KMSpico.exe:
/silent
/backup
/status
/removewatermark
/restorewatermark
/nolog


if you experience problems: disable your antivirus / firewall


if you have used an OEM/Retail key to install windows and KMSpico doesn't work:
to uninstall product key open "cmd" with admin rights and run
slmgr /upk


also you might want to know that "KMSpico.exe" extracts itself to "%temp%\KMSpico\"
then "portable.cmd" - "autopico.exe" is run

the 2 files SECOH-QAD.exe / SECOH-QAD.dll are temporarily dropped into "%windir%"
and might also cause an AV false positive alarm


have fun!

nova-s :)
